// Mobile menu toggle
const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    mainNav.classList.toggle('active');
  });

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!mainNav.contains(e.target) && !menuToggle.contains(e.target)) {
      mainNav.classList.remove('active');
    }
  });
}

// Search Modal
const modalClose = document.getElementById('modalClose');
const searchModal = document.getElementById('searchModal');
const searchTriggers = document.querySelectorAll('.search-btn');

searchTriggers.forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    searchModal.classList.add('active');
  });
});

if (modalClose) {
  modalClose.addEventListener('click', () => {
    searchModal.classList.remove('active');
  });
}

if (searchModal) {
  searchModal.addEventListener('click', (e) => {
    if (e.target === searchModal) {
      searchModal.classList.remove('active');
    }
  });
}

// Scroll to Top
const scrollTopBtn = document.getElementById('scrollTop');

window.addEventListener('scroll', () => {
  if (window.pageYOffset > 300) {
    scrollTopBtn.classList.add('visible');
  } else {
    scrollTopBtn.classList.remove('visible');
  }
});

if (scrollTopBtn) {
  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// CAPTCHA refresh
function refreshCaptcha() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let captcha = '';
  for (let i = 0; i < 5; i++) {
    captcha += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  const captchaEl = document.getElementById('captchaText');
  if (captchaEl) {
    captchaEl.textContent = captcha;
  }
}

// Visa search form submission
const visaForm = document.getElementById('visaSearchForm');
if (visaForm) {
  visaForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const passport = document.getElementById('passportNumber').value;
    const dob = document.getElementById('dateOfBirth').value;
    const code = document.getElementById('confirmationCode').value;

    if (!passport || !dob || !code) {
      alert('Please fill in all required fields.');
      return;
    }

    alert(`Searching for application...\nPassport: ${passport}\nDate of Birth: ${dob}\nConfirmation Code: ${code}`);
  });
}

// Top search form
const topSearch = document.getElementById('searchFormTop');
if (topSearch) {
  topSearch.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = document.getElementById('topSearchInput').value;
    if (query && searchModal) {
      searchModal.classList.add('active');
    }
  });
}

// Initialize random captcha on load
document.addEventListener('DOMContentLoaded', () => {
  refreshCaptcha();
});