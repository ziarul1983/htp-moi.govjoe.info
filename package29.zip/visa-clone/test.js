const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  const filePath = 'file://' + path.resolve(__dirname, 'index.html');
  console.log('Loading:', filePath);

  await page.goto(filePath, { waitUntil: 'networkidle' });

  // Take initial screenshot
  await page.screenshot({ path: 'screenshot-full.png', fullPage: true });
  console.log('Full page screenshot taken');

  // Check key elements exist
  const checks = [
    { selector: '.top-header', name: 'Top Header' },
    { selector: '.main-header', name: 'Main Header' },
    { selector: '.visa-search-section', name: 'Visa Search Section' },
    { selector: '#passportNumber', name: 'Passport Input' },
    { selector: '#dateOfBirth', name: 'Date of Birth Input' },
    { selector: '#confirmationCode', name: 'Confirmation Code Input' },
    { selector: '.captcha-image', name: 'Captcha' },
    { selector: '.btn-primary', name: 'Search Button' },
    { selector: '.site-footer', name: 'Footer' },
    { selector: '.footer-logo img', name: 'Footer Logo' }
  ];

  console.log('\n--- Element Check ---');
  for (const check of checks) {
    const exists = await page.$(check.selector);
    console.log(`${exists ? '✓' : '✗'} ${check.name}`);
  }

  // Test form interaction
  console.log('\n--- Form Interaction ---');
  await page.fill('#passportNumber', 'JORD123456');
  await page.fill('#dateOfBirth', '1990-01-01');
  await page.fill('#confirmationCode', 'A7K9P');

  const passportVal = await page.inputValue('#passportNumber');
  const dobVal = await page.inputValue('#dateOfBirth');
  const codeVal = await page.inputValue('#confirmationCode');

  console.log(`Passport: ${passportVal}`);
  console.log(`DOB: ${dobVal}`);
  console.log(`Code: ${codeVal}`);

  // Take viewport screenshot
  await page.screenshot({ path: 'screenshot-viewport.png', fullPage: false });
  console.log('\nViewport screenshot taken');

  // Test scroll to top
  await page.evaluate(() => window.scrollTo(0, 500));
  await page.waitForTimeout(500);
  const scrollBtnVisible = await page.$('.scroll-top.visible');
  console.log(`\nScroll to top button visible after scroll: ${scrollBtnVisible ? 'Yes' : 'No'}`);

  // Mobile view
  await page.setViewportSize({ width: 375, height: 667 });
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'screenshot-mobile.png', fullPage: true });
  console.log('Mobile screenshot taken');

  console.log('\n✓ All tests completed successfully');

  await browser.close();
})().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});